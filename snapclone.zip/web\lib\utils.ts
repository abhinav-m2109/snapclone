import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { formatDistanceToNow } from "date-fns";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatTimeAgo(date: string | Date) {
  return formatDistanceToNow(new Date(date), { addSuffix: true });
}

export function getInitials(name: string) {
  if (!name) return "?";
  return name.charAt(0).toUpperCase();
}

export function getSnapStatusColor(status: string) {
  switch (status) {
    case 'sent': return '#8B5CF6';
    case 'delivered': return '#FF3B30';
    case 'opened': return '#9CA3AF';
    default: return '#9CA3AF';
  }
}

export function getSnapStatusLabel(status: string) {
  switch (status) {
    case 'sent': return 'Sent';
    case 'delivered': return 'Delivered';
    case 'opened': return 'Opened';
    default: return status;
  }
}

export function generateChatId(uid1: string, uid2: string) {
  return [uid1, uid2].sort().join('_');
}

export async function compressImage(dataUrl: string, quality = 0.7): Promise<string> {
  return new Promise((resolve) => {
    const img = new Image();
    img.src = dataUrl;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      if (!ctx) return resolve(dataUrl);
      ctx.drawImage(img, 0, 0);
      resolve(canvas.toDataURL('image/jpeg', quality));
    };
  });
}
