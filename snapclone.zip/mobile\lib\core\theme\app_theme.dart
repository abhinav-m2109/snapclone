import 'package:flutter/material.dart';

class AppTheme {
  static const Color snapYellow = Color(0xFFFFFC00);
  static const Color snapDark = Color(0xFF0D0D0D);
  static const Color snapGray = Color(0xFF1E1E1E);
  static const Color snapLightGray = Color(0xFF2C2C2C);
  static const Color snapRed = Color(0xFFFF0049);
  static const Color snapPurple = Color(0xFFB92CFF);
  static const Color snapBlue = Color(0xFF00A2FF);

  static ThemeData get darkTheme {
    return ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: snapDark,
      primaryColor: snapYellow,
      colorScheme: const ColorScheme.dark(
        primary: snapYellow,
        secondary: snapYellow,
        background: snapDark,
        surface: snapGray,
      ),
      fontFamily: 'Inter',
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: snapYellow,
          foregroundColor: Colors.black,
          minimumSize: const Size(double.infinity, 50),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(25),
          ),
          textStyle: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: snapLightGray,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: const BorderSide(color: snapYellow, width: 2),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: snapDark,
        selectedItemColor: snapYellow,
        unselectedItemColor: Colors.grey,
        type: BottomNavigationBarType.fixed,
        showSelectedLabels: false,
        showUnselectedLabels: false,
      ),
      cardTheme: CardTheme(
        color: snapGray,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
      ),
    );
  }
}
