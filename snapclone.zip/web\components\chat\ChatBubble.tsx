'use client';
import { Message, Profile } from '@/lib/types';
import { cn, formatTimeAgo, getSnapStatusColor, getSnapStatusLabel } from '@/lib/utils';
import { Camera } from 'lucide-react';

export default function ChatBubble({ message, isSent, senderProfile }: { message: Message, isSent: boolean, senderProfile?: Profile }) {
  if (message.message_type === 'text') {
    return (
      <div className={cn("flex flex-col mb-4", isSent ? "items-end" : "items-start")}>
        <div className={cn(
          "max-w-xs md:max-w-sm px-4 py-2 rounded-2xl",
          isSent ? "bg-[#FFFC00] text-black rounded-br-sm" : "bg-white/10 text-white rounded-bl-sm"
        )}>
          {message.content}
        </div>
        <span className="text-xs text-white/40 mt-1">{formatTimeAgo(message.created_at)}</span>
      </div>
    );
  }

  // Snap message
  return (
    <div className={cn("flex flex-col mb-4", isSent ? "items-end" : "items-start")}>
      <button className="flex items-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors border border-white/10">
        <div 
          className="w-12 h-12 rounded-lg flex items-center justify-center"
          style={{ backgroundColor: getSnapStatusColor(message.status) }}
        >
          <Camera size={24} className="text-white" />
        </div>
        <div className="text-left">
          <p className="text-white font-semibold">{isSent ? 'Sent' : (message.status === 'opened' ? 'Opened' : 'Tap to view')}</p>
          <p className="text-white/50 text-xs">{getSnapStatusLabel(message.status)} • {formatTimeAgo(message.created_at)}</p>
        </div>
      </button>
    </div>
  );
}
