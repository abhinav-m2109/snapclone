import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { Camera, PlaySquare, MessageSquare, Compass } from 'lucide-react';
import NavItem from '@/components/ui/NavItem';
import Avatar from '@/components/ui/Avatar';

export default async function MainLayout({ children }: { children: React.ReactNode }) {
  const supabase = createClient();
  const { data: { session } } = await supabase.auth.getSession();

  if (!session) {
    redirect('/login');
  }

  const { data: profile } = await supabase.from('profiles').select('*').eq('id', session.user.id).single();

  return (
    <div className="flex h-screen bg-[#0D0D0D] text-white overflow-hidden">
      <aside className="hidden md:flex flex-col w-64 border-r border-white/10 p-4">
        <div className="flex items-center gap-3 mb-10 px-2">
          <div className="w-10 h-10 bg-[#FFFC00] rounded-lg flex items-center justify-center">
            <Camera size={24} className="text-black" />
          </div>
          <span className="text-xl font-bold">SnapClone</span>
        </div>
        <nav className="flex-1 space-y-2">
          <NavItem icon={Camera} label="Camera" href="/" />
          <NavItem icon={PlaySquare} label="Stories" href="/stories" />
          <NavItem icon={MessageSquare} label="Chat" href="/chat" />
          <NavItem icon={Compass} label="Discover" href="/discover" />
        </nav>
        <div className="flex items-center gap-3 mt-auto pt-4 border-t border-white/10 px-2">
          <Avatar profile={profile} size="md" />
          <div className="flex-1 min-w-0">
            <p className="font-semibold truncate">{profile?.display_name}</p>
            <p className="text-sm text-gray-400 truncate">@{profile?.username}</p>
          </div>
        </div>
      </aside>

      <main className="flex-1 relative overflow-y-auto">
        {children}
      </main>

      <nav className="md:hidden fixed bottom-0 w-full bg-black/90 backdrop-blur-lg border-t border-white/10 flex justify-around p-3 pb-safe z-40">
        <NavItem icon={Camera} label="Camera" href="/" />
        <NavItem icon={PlaySquare} label="Stories" href="/stories" />
        <NavItem icon={MessageSquare} label="Chat" href="/chat" />
        <NavItem icon={Compass} label="Discover" href="/discover" />
      </nav>
    </div>
  );
}
