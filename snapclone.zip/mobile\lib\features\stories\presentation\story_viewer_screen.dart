import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:go_router/go_router.dart';

const snapDark = Color(0xFF0D0D0D);

class StoryViewerScreen extends StatefulWidget {
  final List<Map<String, dynamic>> stories;

  const StoryViewerScreen({Key? key, required this.stories}) : super(key: key);

  @override
  State<StoryViewerScreen> createState() => _StoryViewerScreenState();
}

class _StoryViewerScreenState extends State<StoryViewerScreen> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  VideoPlayerController? _videoController;
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(vsync: this);
    _animationController.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        _nextStory();
      }
    });
    _loadStory();
  }

  Future<void> _loadStory() async {
    final story = widget.stories[_currentIndex];
    final isVideo = story['media_type'] == 'video';
    
    // Upsert view
    try {
      final userId = Supabase.instance.client.auth.currentUser!.id;
      await Supabase.instance.client.from('story_views').upsert({
        'story_id': story['id'],
        'viewer_id': userId,
      });
    } catch (_) {}

    _animationController.stop();
    _animationController.reset();

    if (_videoController != null) {
      await _videoController!.dispose();
      _videoController = null;
    }

    if (isVideo) {
      _videoController = VideoPlayerController.network(story['media_url'])
        ..initialize().then((_) {
          setState(() {});
          _videoController!.play();
          _animationController.duration = _videoController!.value.duration;
          _animationController.forward();
        });
    } else {
      _animationController.duration = const Duration(seconds: 5);
      _animationController.forward();
      setState(() {});
    }
  }

  void _nextStory() {
    if (_currentIndex < widget.stories.length - 1) {
      setState(() => _currentIndex++);
      _loadStory();
    } else {
      context.pop();
    }
  }

  void _prevStory() {
    if (_currentIndex > 0) {
      setState(() => _currentIndex--);
      _loadStory();
    }
  }

  void _onTapDown(TapDownDetails details) {
    final width = MediaQuery.of(context).size.width;
    if (details.globalPosition.dx < width / 3) {
      _prevStory();
    } else {
      _nextStory();
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    _videoController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.stories.isEmpty) return const Scaffold(backgroundColor: snapDark);
    
    final story = widget.stories[_currentIndex];
    final profile = story['profiles'] as Map<String, dynamic>? ?? {};

    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTapDown: _onTapDown,
        onVerticalDragUpdate: (details) {
          if (details.primaryDelta! > 10) context.pop();
        },
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (story['media_type'] == 'image')
              Image.network(story['media_url'], fit: BoxFit.cover),
            if (story['media_type'] == 'video' && _videoController != null && _videoController!.value.isInitialized)
              VideoPlayer(_videoController!),
            
            // Overlays
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: Container(
                padding: const EdgeInsets.only(top: 40, left: 16, right: 16, bottom: 16),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.black54, Colors.transparent],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
                child: Column(
                  children: [
                    Row(
                      children: List.generate(
                        widget.stories.length,
                        (index) => Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 2),
                            child: AnimatedBuilder(
                              animation: _animationController,
                              builder: (context, child) {
                                double value = 0.0;
                                if (index < _currentIndex) value = 1.0;
                                else if (index == _currentIndex) value = _animationController.value;
                                return LinearProgressIndicator(
                                  value: value,
                                  backgroundColor: Colors.white30,
                                  valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
                                  minHeight: 4,
                                );
                              },
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        CircleAvatar(
                          backgroundImage: profile['avatar_url'] != null ? NetworkImage(profile['avatar_url']) : null,
                          child: profile['avatar_url'] == null ? const Icon(Icons.person) : null,
                        ),
                        const SizedBox(width: 8),
                        Text(profile['display_name'] ?? '', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                        const Spacer(),
                        IconButton(icon: const Icon(Icons.close, color: Colors.white), onPressed: () => context.pop()),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            
            if (story['caption'] != null && story['caption'].toString().isNotEmpty)
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Container(
                  padding: const EdgeInsets.all(32),
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.transparent, Colors.black87],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                  child: Center(
                    child: Text(
                      story['caption'],
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
