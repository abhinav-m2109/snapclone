import { GoRouter } from 'go_router';
import { flutter_riverpod } from 'flutter_riverpod';
import 'package:flutter/material.dart';

// Note: In a complete app, we would import all the screen widgets here.
// For now, this serves as the routing structure.

final appRouterProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: '/login',
    routes: [
      GoRoute(
        path: '/login',
        builder: (context, state) => const Scaffold(body: Center(child: Text('Login Screen'))),
      ),
      GoRoute(
        path: '/signup',
        builder: (context, state) => const Scaffold(body: Center(child: Text('Signup Screen'))),
      ),
      GoRoute(
        path: '/',
        builder: (context, state) => const Scaffold(body: Center(child: Text('Camera Home'))),
      ),
      GoRoute(
        path: '/chat',
        builder: (context, state) => const Scaffold(body: Center(child: Text('Chat Inbox'))),
      ),
      GoRoute(
        path: '/chat/:id',
        builder: (context, state) => const Scaffold(body: Center(child: Text('Chat Thread'))),
      ),
      GoRoute(
        path: '/stories',
        builder: (context, state) => const Scaffold(body: Center(child: Text('Stories'))),
      ),
      GoRoute(
        path: '/discover',
        builder: (context, state) => const Scaffold(body: Center(child: Text('Discover'))),
      ),
      GoRoute(
        path: '/map',
        builder: (context, state) => const Scaffold(body: Center(child: Text('Map'))),
      ),
    ],
  );
});
