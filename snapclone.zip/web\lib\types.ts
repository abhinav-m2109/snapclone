export type Profile = {
  id: string;
  username: string;
  display_name: string;
  avatar_url: string | null;
  snap_score: number;
  ghost_mode: boolean;
  created_at: string;
};

export type Story = {
  id: string;
  user_id: string;
  media_url: string;
  media_type: 'image' | 'video';
  duration: number;
  caption: string | null;
  expires_at: string;
  created_at: string;
  profiles?: Profile;
};

export type Message = {
  id: string;
  chat_id: string;
  sender_id: string;
  message_type: 'text' | 'snap_image' | 'snap_video';
  content: string | null;
  status: 'sent' | 'delivered' | 'opened';
  duration: number | null;
  created_at: string;
  opened_at: string | null;
};

export type Chat = {
  id: string;
  is_group: boolean;
  name: string | null;
  created_at: string;
  updated_at: string;
};

export type DiscoverPost = {
  id: string;
  user_id: string;
  media_url: string;
  media_type: 'image' | 'video';
  caption: string | null;
  likes_count: number;
  created_at: string;
  profiles?: Profile;
};
