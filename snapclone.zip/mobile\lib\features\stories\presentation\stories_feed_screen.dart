import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_animate/flutter_animate.dart';

const snapDark = Color(0xFF0D0D0D);

class StoriesFeedScreen extends StatefulWidget {
  const StoriesFeedScreen({Key? key}) : super(key: key);

  @override
  State<StoriesFeedScreen> createState() => _StoriesFeedScreenState();
}

class _StoriesFeedScreenState extends State<StoriesFeedScreen> {
  List<Map<String, dynamic>> _stories = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadStories();
  }

  Future<void> _loadStories() async {
    setState(() => _isLoading = true);
    try {
      final res = await Supabase.instance.client
          .from('stories')
          .select('*, profiles(id, username, display_name, avatar_url)')
          .order('created_at', ascending: false);
      if (mounted) setState(() {
        _stories = List<Map<String, dynamic>>.from(res);
        _isLoading = false;
      });
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _openStory(List<Map<String, dynamic>> stories) {
    context.push('/story-viewer', extra: stories);
  }

  Widget _buildStoryBubble(Map<String, dynamic> story) {
    final profile = story['profiles'] as Map<String, dynamic>;
    return GestureDetector(
      onTap: () => _openStory([story]),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 8),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(3),
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(colors: [Colors.purple, Colors.red, Colors.yellow]),
              ),
              child: CircleAvatar(
                radius: 30,
                backgroundImage: profile['avatar_url'] != null ? NetworkImage(profile['avatar_url']) : null,
                child: profile['avatar_url'] == null ? const Icon(Icons.person) : null,
              ),
            ),
            const SizedBox(height: 4),
            Text(profile['display_name'] ?? '', style: const TextStyle(color: Colors.white, fontSize: 12)),
          ],
        ),
      ),
    ).animate().fadeIn().slideY();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: snapDark,
      appBar: AppBar(
        backgroundColor: snapDark,
        title: const Text('Stories'),
        actions: [IconButton(icon: const Icon(Icons.search), onPressed: () {})],
      ),
      body: RefreshIndicator(
        onRefresh: _loadStories,
        child: _isLoading 
          ? const Center(child: CircularProgressIndicator())
          : CustomScrollView(
              slivers: [
                SliverToBoxAdapter(
                  child: SizedBox(
                    height: 100,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: _stories.length,
                      itemBuilder: (context, index) => _buildStoryBubble(_stories[index]),
                    ),
                  ),
                ),
                const SliverToBoxAdapter(child: Divider(color: Colors.white24)),
                SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (context, index) {
                      final story = _stories[index];
                      final profile = story['profiles'] as Map<String, dynamic>;
                      return ListTile(
                        leading: CircleAvatar(
                          backgroundImage: profile['avatar_url'] != null ? NetworkImage(profile['avatar_url']) : null,
                          child: profile['avatar_url'] == null ? const Icon(Icons.person) : null,
                        ),
                        title: Text(profile['display_name'] ?? '', style: const TextStyle(color: Colors.white)),
                        subtitle: Text(story['created_at'] ?? '', style: const TextStyle(color: Colors.white54)),
                        onTap: () => _openStory([story]),
                      ).animate().fadeIn().slideX();
                    },
                    itemCount: _stories.length,
                  ),
                ),
              ],
            ),
      ),
    );
  }
}
