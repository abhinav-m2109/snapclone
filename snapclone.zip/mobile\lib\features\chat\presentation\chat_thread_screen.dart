import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:go_router/go_router.dart';

const snapDark = Color(0xFF0D0D0D);
const snapYellow = Color(0xFFFFFC00);
const snapRed = Color(0xFFFF3B30);
const snapPurple = Color(0xFFB132B4);

class ChatThreadScreen extends StatefulWidget {
  final String chatId;

  const ChatThreadScreen({Key? key, required this.chatId}) : super(key: key);

  @override
  State<ChatThreadScreen> createState() => _ChatThreadScreenState();
}

class _ChatThreadScreenState extends State<ChatThreadScreen> {
  final _textController = TextEditingController();
  List<Map<String, dynamic>> _messages = [];
  Map<String, dynamic>? _otherUser;
  late StreamSubscription _messageSub;
  final String _currentUserId = Supabase.instance.client.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    _loadOtherUser();
    _messageSub = Supabase.instance.client
        .from('messages')
        .stream(primaryKey: ['id'])
        .eq('chat_id', widget.chatId)
        .order('created_at', ascending: false)
        .listen((data) {
          if (mounted) setState(() => _messages = data);
          _markDelivered(data);
        });
  }

  Future<void> _loadOtherUser() async {
    try {
      final parts = await Supabase.instance.client
          .from('chat_participants')
          .select('user_id, profiles(id, display_name, avatar_url)')
          .eq('chat_id', widget.chatId)
          .neq('user_id', _currentUserId)
          .maybeSingle();
      if (parts != null && mounted) {
        setState(() => _otherUser = parts['profiles'] as Map<String, dynamic>);
      }
    } catch (_) {}
  }

  Future<void> _markDelivered(List<Map<String, dynamic>> msgs) async {
    final unread = msgs.where((m) => m['sender_id'] != _currentUserId && m['status'] == 'sent').map((m) => m['id']).toList();
    if (unread.isNotEmpty) {
      await Supabase.instance.client.from('messages').update({'status': 'delivered'}).inFilter('id', unread);
    }
  }

  Future<void> _sendText() async {
    final text = _textController.text.trim();
    if (text.isEmpty) return;
    _textController.clear();
    try {
      await Supabase.instance.client.from('messages').insert({
        'chat_id': widget.chatId,
        'sender_id': _currentUserId,
        'type': 'text',
        'content': text,
        'status': 'sent'
      });
    } catch (_) {}
  }

  @override
  void dispose() {
    _textController.dispose();
    _messageSub.cancel();
    super.dispose();
  }

  Widget _buildMessage(Map<String, dynamic> msg) {
    final isMine = msg['sender_id'] == _currentUserId;
    if (msg['type'] == 'text') {
      return Align(
        alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 16),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: isMine ? snapYellow : Colors.grey[800],
            borderRadius: BorderRadius.circular(16),
          ),
          child: Text(msg['content'] ?? '', style: TextStyle(color: isMine ? Colors.black : Colors.white)),
        ),
      );
    } else { // Snap
      final color = msg['media_type'] == 'video' ? snapPurple : snapRed;
      final status = msg['status'];
      return Align(
        alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
        child: GestureDetector(
          onTap: () {
            if (!isMine && status != 'opened') {
              context.push('/snap-view/${msg['id']}');
            }
          },
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 16),
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: status == 'opened' ? Colors.grey[900] : color,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: status == 'opened' ? Colors.grey : Colors.transparent),
            ),
            child: Center(
              child: Icon(
                status == 'opened' ? Icons.check : (msg['media_type'] == 'video' ? Icons.videocam : Icons.camera_alt),
                color: status == 'opened' ? Colors.grey : Colors.white,
                size: 32,
              ),
            ),
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: snapDark,
      appBar: AppBar(
        backgroundColor: snapDark,
        title: Row(
          children: [
            if (_otherUser != null)
              CircleAvatar(
                radius: 16,
                backgroundImage: _otherUser!['avatar_url'] != null ? NetworkImage(_otherUser!['avatar_url']) : null,
                child: _otherUser!['avatar_url'] == null ? const Icon(Icons.person, size: 16) : null,
              ),
            const SizedBox(width: 8),
            Text(_otherUser?['display_name'] ?? 'Chat'),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              reverse: true,
              itemCount: _messages.length,
              itemBuilder: (context, index) => _buildMessage(_messages[index]),
            ),
          ),
          Container(
            padding: const EdgeInsets.all(8),
            color: Colors.black,
            child: Row(
              children: [
                IconButton(icon: const Icon(Icons.camera_alt, color: Colors.white54), onPressed: () => context.go('/camera')),
                Expanded(
                  child: TextField(
                    controller: _textController,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      hintText: 'Send a chat',
                      hintStyle: const TextStyle(color: Colors.white54),
                      filled: true,
                      fillColor: Colors.grey[900],
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    ),
                  ),
                ),
                IconButton(icon: const Icon(Icons.send, color: snapYellow), onPressed: _sendText),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
