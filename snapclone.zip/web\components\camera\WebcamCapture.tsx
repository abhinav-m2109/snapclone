'use client';
import Webcam from 'react-webcam';
import { useRef, useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

const FILTERS = [
  { name: 'Normal', style: '' },
  { name: 'B&W', style: 'grayscale(100%)' },
  { name: 'Sepia', style: 'sepia(100%)' },
  { name: 'Vivid', style: 'saturate(200%) contrast(110%)' },
  { name: 'Cool', style: 'hue-rotate(30deg) saturate(120%)' },
  { name: 'Warm', style: 'sepia(50%) saturate(150%)' },
];

export default function WebcamCapture({ onCapture }: { onCapture: (dataUrl: string) => void }) {
  const webcamRef = useRef<Webcam>(null);
  const [activeFilter, setActiveFilter] = useState(FILTERS[0]);

  const capture = useCallback(() => {
    const imageSrc = webcamRef.current?.getScreenshot();
    if (imageSrc) {
      onCapture(imageSrc); // In a real app, apply CSS filter to canvas before saving
    }
  }, [webcamRef, onCapture]);

  return (
    <div className="relative w-full h-full max-w-md mx-auto flex flex-col items-center">
      <div className="relative w-full aspect-[9/16] bg-gray-900 rounded-3xl overflow-hidden shadow-2xl">
        <Webcam
          ref={webcamRef}
          audio={false}
          screenshotFormat="image/jpeg"
          videoConstraints={{ facingMode: "user" }}
          className="absolute inset-0 w-full h-full object-cover"
          style={{ filter: activeFilter.style }}
        />
      </div>

      <div className="absolute bottom-32 w-full overflow-x-auto whitespace-nowrap px-4 py-2 hide-scrollbar">
        <div className="flex gap-4">
          {FILTERS.map((f) => (
            <button
              key={f.name}
              onClick={() => setActiveFilter(f)}
              className={cn(
                "px-4 py-2 rounded-full backdrop-blur-md transition-colors",
                activeFilter.name === f.name ? "bg-[#FFFC00] text-black font-bold" : "bg-black/50 text-white border border-white/20"
              )}
            >
              {f.name}
            </button>
          ))}
        </div>
      </div>

      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={capture}
        className="absolute bottom-8 w-20 h-20 rounded-full border-4 border-white/50 p-1"
      >
        <div className="w-full h-full bg-white rounded-full"></div>
      </motion.button>
    </div>
  );
}
