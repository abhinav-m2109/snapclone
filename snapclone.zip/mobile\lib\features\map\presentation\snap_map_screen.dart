import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SnapMapScreen extends StatefulWidget {
  const SnapMapScreen({Key? key}) : super(key: key);

  @override
  State<SnapMapScreen> createState() => _SnapMapScreenState();
}

class _SnapMapScreenState extends State<SnapMapScreen> {
  GoogleMapController? _mapController;
  final Set<Marker> _markers = {};
  StreamSubscription<Position>? _positionStream;
  bool _ghostMode = false;
  final String _currentUserId = Supabase.instance.client.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    _initMap();
  }

  Future<void> _initMap() async {
    final status = await Permission.location.request();
    if (status.isGranted) {
      _startLocationUpdates();
      _loadGhostMode();
      _loadFriendsLocations();
    }
  }

  Future<void> _loadGhostMode() async {
    try {
      final res = await Supabase.instance.client.from('profiles').select('ghost_mode').eq('id', _currentUserId).single();
      setState(() => _ghostMode = res['ghost_mode'] ?? false);
    } catch (_) {}
  }

  void _startLocationUpdates() {
    _positionStream = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 50),
    ).listen((Position position) {
      if (_mapController != null) {
        _mapController!.animateCamera(CameraUpdate.newLatLng(LatLng(position.latitude, position.longitude)));
      }
      if (!_ghostMode) {
        _uploadLocation(position);
      }
    });
  }

  Future<void> _uploadLocation(Position pos) async {
    try {
      await Supabase.instance.client.from('locations').upsert({
        'user_id': _currentUserId,
        'lat': pos.latitude,
        'lng': pos.longitude,
        'geohash': '${pos.latitude.toStringAsFixed(3)},${pos.longitude.toStringAsFixed(3)}',
      });
    } catch (_) {}
  }

  Future<void> _loadFriendsLocations() async {
    try {
      // In a real app, join with friendships to only show friends where ghost_mode=false
      // For simplicity, fetch all non-ghost locations
      final res = await Supabase.instance.client.from('locations').select('*, profiles!inner(display_name, ghost_mode)').eq('profiles.ghost_mode', false).neq('user_id', _currentUserId);
      
      final Set<Marker> newMarkers = {};
      for (var loc in res) {
        newMarkers.add(
          Marker(
            markerId: MarkerId(loc['user_id']),
            position: LatLng(loc['lat'], loc['lng']),
            infoWindow: InfoWindow(title: loc['profiles']['display_name']),
            icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
          ),
        );
      }
      setState(() => _markers.addAll(newMarkers));
    } catch (_) {}
  }

  Future<void> _toggleGhostMode() async {
    final newMode = !_ghostMode;
    setState(() => _ghostMode = newMode);
    try {
      await Supabase.instance.client.from('profiles').update({'ghost_mode': newMode}).eq('id', _currentUserId);
      if (newMode) {
        await Supabase.instance.client.from('locations').delete().eq('user_id', _currentUserId);
      } else {
        final pos = await Geolocator.getCurrentPosition();
        _uploadLocation(pos);
      }
    } catch (_) {}
  }

  @override
  void dispose() {
    _positionStream?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          GoogleMap(
            initialCameraPosition: const CameraPosition(target: LatLng(0, 0), zoom: 2),
            myLocationEnabled: true,
            myLocationButtonEnabled: false,
            zoomControlsEnabled: false,
            mapType: MapType.normal,
            markers: _markers,
            onMapCreated: (controller) => _mapController = controller,
          ),
          SafeArea(
            child: Align(
              alignment: Alignment.bottomRight,
              child: Padding(
                padding: const EdgeInsets.only(bottom: 100, right: 16), // above bottom nav
                child: FloatingActionButton(
                  backgroundColor: Colors.white,
                  onPressed: _toggleGhostMode,
                  child: Icon(
                    _ghostMode ? Icons.visibility_off : Icons.visibility,
                    color: Colors.black,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
