import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';

class CameraScreen extends StatefulWidget {
  const CameraScreen({Key? key}) : super(key: key);

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  CameraController? _controller;
  List<CameraDescription> _cameras = [];
  bool _isRecording = false;
  int _selectedFilterIndex = 0;
  bool _isFrontCamera = true;
  FlashMode _flashMode = FlashMode.off;

  final List<List<double>> _filters = [
    [1,0,0,0,0, 0,1,0,0,0, 0,0,1,0,0, 0,0,0,1,0], // Normal
    [0.33,0.33,0.33,0,0, 0.33,0.33,0.33,0,0, 0.33,0.33,0.33,0,0, 0,0,0,1,0], // B&W
    [0.393,0.769,0.189,0,0, 0.349,0.686,0.168,0,0, 0.272,0.534,0.131,0,0, 0,0,0,1,0], // Sepia
    [1.2,0,0,0,0, 0,1.2,0,0,0, 0,0,1.2,0,0, 0,0,0,1,0], // Vivid
    [0.8,0,0,0,0, 0,0.9,0,0,0, 0,0,1.2,0,0, 0,0,0,1,0], // Cool
    [1.2,0,0,0,0, 0,1.1,0,0,0, 0,0,0.8,0,0, 0,0,0,1,0], // Warm
  ];

  final List<String> _filterNames = ['Normal', 'B&W', 'Sepia', 'Vivid', 'Cool', 'Warm'];

  @override
  void initState() {
    super.initState();
    _initCamera();
  }

  Future<void> _initCamera() async {
    await [Permission.camera, Permission.microphone].request();
    _cameras = await availableCameras();
    if (_cameras.isEmpty) return;
    final camera = _cameras.firstWhere((c) => c.lensDirection == CameraLensDirection.front, orElse: () => _cameras.first);
    _isFrontCamera = camera.lensDirection == CameraLensDirection.front;
    _setupController(camera);
  }

  Future<void> _setupController(CameraDescription camera) async {
    _controller = CameraController(camera, ResolutionPreset.high, enableAudio: true);
    await _controller!.initialize();
    await _controller!.setFlashMode(_flashMode);
    if (mounted) setState(() {});
  }

  void _flipCamera() {
    if (_cameras.length < 2) return;
    final newDir = _isFrontCamera ? CameraLensDirection.back : CameraLensDirection.front;
    final camera = _cameras.firstWhere((c) => c.lensDirection == newDir, orElse: () => _cameras.first);
    _isFrontCamera = camera.lensDirection == CameraLensDirection.front;
    _setupController(camera);
  }

  void _toggleFlash() {
    _flashMode = _flashMode == FlashMode.off ? FlashMode.torch : FlashMode.off;
    _controller?.setFlashMode(_flashMode);
    setState(() {});
  }

  Future<void> _takePicture() async {
    if (_controller == null || !_controller!.value.isInitialized || _isRecording) return;
    try {
      final file = await _controller!.takePicture();
      if (mounted) context.push('/snap-preview', extra: {'imagePath': file.path});
    } catch (e) {
      debugPrint(e.toString());
    }
  }

  Future<void> _startVideoRecording() async {
    if (_controller == null || !_controller!.value.isInitialized || _isRecording) return;
    try {
      await _controller!.startVideoRecording();
      setState(() => _isRecording = true);
    } catch (e) {
      debugPrint(e.toString());
    }
  }

  Future<void> _stopVideoRecording() async {
    if (_controller == null || !_controller!.value.isRecordingVideo) return;
    try {
      final file = await _controller!.stopVideoRecording();
      setState(() => _isRecording = false);
      if (mounted) context.push('/snap-preview', extra: {'videoPath': file.path});
    } catch (e) {
      debugPrint(e.toString());
    }
  }

  Future<void> _pickGallery() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (picked != null && mounted) {
      context.push('/snap-preview', extra: {'imagePath': picked.path});
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_controller == null || !_controller!.value.isInitialized) {
      return const Scaffold(backgroundColor: Colors.black, body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          GestureDetector(
            onScaleUpdate: (details) {
              _controller?.setZoomLevel(details.scale.clamp(1.0, 5.0));
            },
            child: ColorFiltered(
              colorFilter: ColorFilter.matrix(_filters[_selectedFilterIndex]),
              child: CameraPreview(_controller!),
            ),
          ),
          SafeArea(
            child: Align(
              alignment: Alignment.topCenter,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CircleAvatar(backgroundColor: Colors.black38, child: IconButton(icon: const Icon(Icons.person, color: Colors.white), onPressed: () {})),
                    CircleAvatar(backgroundColor: Colors.black38, child: IconButton(icon: Icon(_flashMode == FlashMode.torch ? Icons.flash_on : Icons.flash_off, color: Colors.white), onPressed: _toggleFlash)),
                    CircleAvatar(backgroundColor: Colors.black38, child: IconButton(icon: const Icon(Icons.search, color: Colors.white), onPressed: () {})),
                  ],
                ),
              ),
            ),
          ),
          if (_isRecording)
            const Positioned(
              top: 100,
              left: 0,
              right: 0,
              child: Center(child: Icon(Icons.fiber_manual_record, color: Colors.red, size: 40)),
            ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 100.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(
                    height: 50,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: _filters.length,
                      itemBuilder: (context, index) {
                        return GestureDetector(
                          onTap: () => setState(() => _selectedFilterIndex = index),
                          child: Container(
                            margin: const EdgeInsets.symmetric(horizontal: 8),
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: _selectedFilterIndex == index ? Colors.white : Colors.black38,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Center(
                              child: Text(
                                _filterNames[index],
                                style: TextStyle(color: _selectedFilterIndex == index ? Colors.black : Colors.white),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      IconButton(icon: const Icon(Icons.photo_library, color: Colors.white, size: 30), onPressed: _pickGallery),
                      GestureDetector(
                        onTap: _takePicture,
                        onLongPress: _startVideoRecording,
                        onLongPressUp: _stopVideoRecording,
                        child: Container(
                          width: 72,
                          height: 72,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 4),
                            color: _isRecording ? Colors.red : Colors.transparent,
                          ),
                        ),
                      ),
                      IconButton(icon: const Icon(Icons.flip_camera_ios, color: Colors.white, size: 30), onPressed: _flipCamera),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
