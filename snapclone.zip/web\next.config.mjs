/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**', // Allow all for demo purposes, restrict to Supabase URL in prod
      },
      {
        protocol: 'http',
        hostname: 'localhost', // For local supabase
      }
    ],
  },
};

export default nextConfig;
