import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const snapDark = Color(0xFF0D0D0D);
const snapYellow = Color(0xFFFFFC00);

class FriendSearchScreen extends StatefulWidget {
  const FriendSearchScreen({Key? key}) : super(key: key);

  @override
  State<FriendSearchScreen> createState() => _FriendSearchScreenState();
}

class _FriendSearchScreenState extends State<FriendSearchScreen> {
  final _searchController = TextEditingController();
  List<Map<String, dynamic>> _results = [];
  Map<String, String> _friendshipStatus = {}; // userId -> status ('pending', 'accepted')
  bool _isLoading = false;
  Timer? _debounce;
  final String _currentUserId = Supabase.instance.client.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    _loadFriendships();
  }

  Future<void> _loadFriendships() async {
    try {
      final res = await Supabase.instance.client
          .from('friendships')
          .select()
          .or('requester_id.eq.$_currentUserId,addressee_id.eq.$_currentUserId');
      
      final Map<String, String> statuses = {};
      for (var f in res) {
        final otherId = f['requester_id'] == _currentUserId ? f['addressee_id'] : f['requester_id'];
        statuses[otherId] = f['status'];
      }
      if (mounted) setState(() => _friendshipStatus = statuses);
    } catch (_) {}
  }

  void _onSearch(String query) {
    if (_debounce?.isActive ?? false) _debounce!.cancel();
    if (query.isEmpty) {
      setState(() => _results = []);
      return;
    }
    
    setState(() => _isLoading = true);
    _debounce = Timer(const Duration(milliseconds: 500), () async {
      try {
        final res = await Supabase.instance.client
            .from('profiles')
            .select()
            .ilike('username', '%$query%')
            .neq('id', _currentUserId);
        if (mounted) setState(() {
          _results = List<Map<String, dynamic>>.from(res);
          _isLoading = false;
        });
      } catch (_) {
        if (mounted) setState(() => _isLoading = false);
      }
    });
  }

  Future<void> _addFriend(String userId) async {
    try {
      await Supabase.instance.client.from('friendships').insert({
        'requester_id': _currentUserId,
        'addressee_id': userId,
        'status': 'pending'
      });
      setState(() => _friendshipStatus[userId] = 'pending');
    } catch (_) {}
  }

  @override
  void dispose() {
    _searchController.dispose();
    _debounce?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: snapDark,
      appBar: AppBar(
        backgroundColor: snapDark,
        title: const Text('Find Friends'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(60),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              onChanged: _onSearch,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Search username...',
                hintStyle: const TextStyle(color: Colors.white54),
                filled: true,
                fillColor: Colors.grey[900],
                prefixIcon: const Icon(Icons.search, color: Colors.white54),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
              ),
            ),
          ),
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _results.isEmpty && _searchController.text.isNotEmpty
              ? const Center(child: Text('No results found', style: TextStyle(color: Colors.white54)))
              : ListView.builder(
                  itemCount: _results.length,
                  itemBuilder: (context, index) {
                    final user = _results[index];
                    final id = user['id'];
                    final status = _friendshipStatus[id];
                    
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundImage: user['avatar_url'] != null ? NetworkImage(user['avatar_url']) : null,
                        child: user['avatar_url'] == null ? const Icon(Icons.person) : null,
                      ),
                      title: Text(user['display_name'] ?? '', style: const TextStyle(color: Colors.white)),
                      subtitle: Text(user['username'] ?? '', style: const TextStyle(color: Colors.white54)),
                      trailing: _buildActionButton(id, status),
                    );
                  },
                ),
    );
  }

  Widget _buildActionButton(String id, String? status) {
    if (status == 'accepted') {
      return const Icon(Icons.check_circle, color: Colors.green);
    } else if (status == 'pending') {
      return ElevatedButton(
        style: ElevatedButton.styleFrom(backgroundColor: Colors.grey[800], foregroundColor: Colors.white),
        onPressed: null,
        child: const Text('Pending'),
      );
    } else {
      return ElevatedButton(
        style: ElevatedButton.styleFrom(backgroundColor: snapYellow, foregroundColor: Colors.black),
        onPressed: () => _addFriend(id),
        child: const Text('Add'),
      );
    }
  }
}
