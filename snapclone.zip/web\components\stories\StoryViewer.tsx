'use client';
import { useEffect, useState, useRef } from 'react';
import { Story } from '@/lib/types';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import Avatar from '@/components/ui/Avatar';
import { formatTimeAgo } from '@/lib/utils';
import { supabase } from '@/lib/supabase/client';
import useAuth from '@/lib/hooks/useAuth';

export default function StoryViewer({ stories, initialIndex = 0, onClose }: { stories: Story[], initialIndex: number, onClose: () => void }) {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [progress, setProgress] = useState(0);
  const { user } = useAuth();
  
  const DURATION = 5000;
  const currentStory = stories[currentIndex];

  useEffect(() => {
    setProgress(0);
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          handleNext();
          return 100;
        }
        return prev + (100 / (DURATION / 50));
      });
    }, 50);

    // Mark as viewed
    if (user && currentStory) {
      supabase.from('story_views').upsert({ story_id: currentStory.id, viewer_id: user.id }).then();
    }

    return () => clearInterval(interval);
  }, [currentIndex, currentStory, user]);

  const handleNext = () => {
    if (currentIndex < stories.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      onClose();
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
    }
  };

  const handleClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const { clientX } = e;
    const { innerWidth } = window;
    if (clientX < innerWidth * 0.35) {
      handlePrev();
    } else {
      handleNext();
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') handleNext();
      if (e.key === 'ArrowLeft') handlePrev();
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentIndex]);

  if (!currentStory) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black flex items-center justify-center">
      <div className="absolute inset-0 w-full h-full max-w-md mx-auto relative cursor-pointer" onClick={handleClick}>
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStory.id}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="w-full h-full relative"
          >
            {currentStory.media_type === 'video' ? (
              <video src={currentStory.media_url} autoPlay loop muted playsInline className="w-full h-full object-cover" />
            ) : (
              <img src={currentStory.media_url} alt="" className="w-full h-full object-cover" />
            )}
            
            <div className="absolute top-0 inset-x-0 bg-gradient-to-b from-black/60 to-transparent pt-4 px-4 pb-8 pointer-events-none">
              <div className="flex gap-1 mb-4">
                {stories.map((s, idx) => (
                  <div key={s.id} className="flex-1 h-1 bg-white/30 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-white transition-all duration-75"
                      style={{ width: idx < currentIndex ? '100%' : idx === currentIndex ? `${progress}%` : '0%' }}
                    />
                  </div>
                ))}
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Avatar profile={(currentStory as any).profiles} size="sm" />
                  <span className="font-semibold text-white">{(currentStory as any).profiles?.display_name}</span>
                  <span className="text-white/60 text-sm">{formatTimeAgo(currentStory.created_at)}</span>
                </div>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
        
        <button 
          onClick={(e) => { e.stopPropagation(); onClose(); }}
          className="absolute top-10 right-4 z-10 p-2 text-white/80 hover:text-white bg-black/20 rounded-full"
        >
          <X size={24} />
        </button>
      </div>
    </div>
  );
}
