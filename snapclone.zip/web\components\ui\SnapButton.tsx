'use client';
import { ReactNode } from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import LoadingSpinner from './LoadingSpinner';

export default function SnapButton({ 
  children, 
  onClick, 
  disabled, 
  loading, 
  size = 'md', 
  variant = 'primary' 
}: { 
  children: ReactNode, 
  onClick?: () => void, 
  disabled?: boolean, 
  loading?: boolean, 
  size?: 'sm' | 'md' | 'lg', 
  variant?: 'primary' | 'ghost' | 'danger' 
}) {
  const baseClasses = "flex items-center justify-center font-bold rounded-lg transition-all shadow-sm";
  
  const sizeClasses = {
    sm: "px-3 py-1.5 text-sm",
    md: "px-6 py-3 text-base",
    lg: "px-8 py-4 text-lg"
  };

  const variantClasses = {
    primary: "bg-[#FFFC00] text-black hover:brightness-110 shadow-[0_0_15px_rgba(255,252,0,0.3)] hover:shadow-[0_0_25px_rgba(255,252,0,0.5)]",
    ghost: "bg-transparent text-[#FFFC00] border-2 border-[#FFFC00] hover:bg-[#FFFC00]/10",
    danger: "bg-[#FF3B30] text-white hover:brightness-110"
  };

  return (
    <motion.button
      whileHover={disabled || loading ? {} : { scale: 1.02 }}
      whileTap={disabled || loading ? {} : { scale: 0.95 }}
      onClick={onClick}
      disabled={disabled || loading}
      className={cn(
        baseClasses,
        sizeClasses[size],
        variantClasses[variant],
        (disabled || loading) && "opacity-50 cursor-not-allowed"
      )}
    >
      {loading ? <LoadingSpinner size="sm" /> : children}
    </motion.button>
  );
}
