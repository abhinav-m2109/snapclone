'use client';
import { useState, useEffect } from 'react';
import { usePathname } from 'next/navigation';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function NavItem({ icon: Icon, label, href, isActive: forceActive }: { icon: LucideIcon, label: string, href: string, isActive?: boolean }) {
  const pathname = usePathname();
  const isActive = forceActive !== undefined ? forceActive : pathname === href;

  return (
    <Link href={href}>
      {/* Sidebar variant (hidden on mobile) */}
      <div className={cn(
        "hidden md:flex items-center gap-3 px-4 py-3 rounded-lg transition-colors group",
        isActive ? "text-white" : "text-gray-400 hover:text-white hover:bg-white/5"
      )}>
        <Icon size={24} className={cn("transition-colors", isActive ? "text-[#FFFC00]" : "text-gray-400 group-hover:text-white")} />
        <span className={cn("text-lg", isActive && "font-bold")}>{label}</span>
      </div>

      {/* Mobile bottom nav variant */}
      <div className="md:hidden flex flex-col items-center justify-center w-16 h-16">
        <Icon size={24} className={cn("mb-1 transition-colors", isActive ? "text-[#FFFC00]" : "text-gray-400")} />
      </div>
    </Link>
  );
}
