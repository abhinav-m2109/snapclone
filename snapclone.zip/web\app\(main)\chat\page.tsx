'use client';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase/client';
import useAuth from '@/lib/hooks/useAuth';
import Avatar from '@/components/ui/Avatar';
import { formatTimeAgo } from '@/lib/utils';
import Link from 'next/link';

export default function ChatPage() {
  const { user } = useAuth();
  const [chats, setChats] = useState<any[]>([]);

  useEffect(() => {
    if (!user) return;
    // Mock fetching chats
    const fetchChats = async () => {
      // Simplified query for UI
      setChats([]);
    };
    fetchChats();
  }, [user]);

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-6 text-white">Chats</h1>
      {chats.length === 0 ? (
        <p className="text-gray-400 text-center mt-10">No chats yet. Add friends to start snapping!</p>
      ) : (
        <div className="space-y-4">
          {/* Render list of chats */}
        </div>
      )}
    </div>
  );
}
