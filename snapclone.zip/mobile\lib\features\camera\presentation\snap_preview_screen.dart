import 'dart:io';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:video_player/video_player.dart';

const snapYellow = Color(0xFFFFFC00);

class SnapPreviewScreen extends StatefulWidget {
  final String? imagePath;
  final String? videoPath;

  const SnapPreviewScreen({Key? key, this.imagePath, this.videoPath}) : super(key: key);

  @override
  State<SnapPreviewScreen> createState() => _SnapPreviewScreenState();
}

class _SnapPreviewScreenState extends State<SnapPreviewScreen> {
  VideoPlayerController? _videoController;
  bool _showTextOverlay = false;
  final _captionController = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.videoPath != null) {
      _videoController = VideoPlayerController.file(File(widget.videoPath!))
        ..initialize().then((_) {
          _videoController!.setLooping(true);
          _videoController!.play();
          setState(() {});
        });
    }
  }

  @override
  void dispose() {
    _videoController?.dispose();
    _captionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          if (widget.imagePath != null)
            Image.file(File(widget.imagePath!), fit: BoxFit.cover),
          if (widget.videoPath != null && _videoController != null && _videoController!.value.isInitialized)
            VideoPlayer(_videoController!),
          
          SafeArea(
            child: Align(
              alignment: Alignment.topCenter,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(icon: const Icon(Icons.close, color: Colors.white, size: 30), onPressed: () => context.pop()),
                    IconButton(
                      icon: const Icon(Icons.text_fields, color: Colors.white, size: 30),
                      onPressed: () => setState(() => _showTextOverlay = !_showTextOverlay),
                    ),
                  ],
                ),
              ),
            ),
          ),

          if (_showTextOverlay)
            Center(
              child: Container(
                color: Colors.black54,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: TextField(
                  controller: _captionController,
                  autofocus: true,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                  decoration: const InputDecoration(border: InputBorder.none, hintText: 'Add a caption...', hintStyle: TextStyle(color: Colors.white54)),
                ),
              ),
            ),

          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  OutlinedButton.icon(
                    icon: const Icon(Icons.add, color: Colors.white),
                    label: const Text('Story', style: TextStyle(color: Colors.white)),
                    style: OutlinedButton.styleFrom(side: const BorderSide(color: Colors.white), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
                    onPressed: () {
                      context.push('/send-to', extra: {
                        'imagePath': widget.imagePath,
                        'videoPath': widget.videoPath,
                        'caption': _captionController.text,
                        'addToStory': true,
                      });
                    },
                  ),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: snapYellow, foregroundColor: Colors.black, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
                    onPressed: () {
                      context.push('/send-to', extra: {
                        'imagePath': widget.imagePath,
                        'videoPath': widget.videoPath,
                        'caption': _captionController.text,
                        'addToStory': false,
                      });
                    },
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [Text('Send To '), Icon(Icons.arrow_forward_ios, size: 16)],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
