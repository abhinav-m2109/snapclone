'use client';
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase/client';
import { Story, Profile } from '@/lib/types';
import StoryBubble from '@/components/stories/StoryBubble';
import StoryViewer from '@/components/stories/StoryViewer';

export default function StoriesPage() {
  const [groupedStories, setGroupedStories] = useState<{ profile: Profile, stories: Story[] }[]>([]);
  const [selectedUserIndex, setSelectedUserIndex] = useState<number | null>(null);

  useEffect(() => {
    // Mock fetch for stories, implement join logic here
    const fetchStories = async () => {
      const { data, error } = await supabase.from('stories').select('*, profiles(*)').order('created_at', { ascending: false });
      if (data) {
        // Group by user logic goes here
        // Set state
      }
    };
    fetchStories();
  }, []);

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-6 text-white">Friends' Stories</h1>
      <div className="flex gap-4 overflow-x-auto pb-4 hide-scrollbar">
        {groupedStories.map((group, idx) => (
          <StoryBubble 
            key={group.profile.id} 
            profile={group.profile} 
            stories={group.stories} 
            viewed={false} 
            onClick={() => setSelectedUserIndex(idx)} 
          />
        ))}
      </div>
      
      {selectedUserIndex !== null && (
        <StoryViewer 
          stories={groupedStories[selectedUserIndex].stories} 
          initialIndex={0} 
          onClose={() => setSelectedUserIndex(null)} 
        />
      )}
    </div>
  );
}
