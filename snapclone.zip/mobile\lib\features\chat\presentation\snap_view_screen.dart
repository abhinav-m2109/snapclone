import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:go_router/go_router.dart';
import 'package:video_player/video_player.dart';

const snapDark = Color(0xFF0D0D0D);

class SnapViewScreen extends StatefulWidget {
  final String messageId;

  const SnapViewScreen({Key? key, required this.messageId}) : super(key: key);

  @override
  State<SnapViewScreen> createState() => _SnapViewScreenState();
}

class _SnapViewScreenState extends State<SnapViewScreen> with SingleTickerProviderStateMixin {
  Map<String, dynamic>? _message;
  VideoPlayerController? _videoController;
  late AnimationController _animationController;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(vsync: this);
    _animationController.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        context.pop();
      }
    });
    _loadSnap();
  }

  Future<void> _loadSnap() async {
    try {
      final res = await Supabase.instance.client.from('messages').select().eq('id', widget.messageId).single();
      setState(() {
        _message = res;
        _isLoading = false;
      });

      await Supabase.instance.client.from('messages').update({
        'status': 'opened',
        'opened_at': DateTime.now().toIso8601String(),
      }).eq('id', widget.messageId);

      if (_message!['media_type'] == 'video') {
        _videoController = VideoPlayerController.network(_message!['media_url'])
          ..initialize().then((_) {
            _videoController!.play();
            _animationController.duration = _videoController!.value.duration;
            _animationController.forward();
            setState(() {});
          });
      } else {
        _animationController.duration = Duration(seconds: _message!['duration'] ?? 5);
        _animationController.forward();
        setState(() {});
      }
    } catch (_) {
      if (mounted) context.pop();
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    _videoController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) return const Scaffold(backgroundColor: Colors.black, body: Center(child: CircularProgressIndicator()));

    return WillPopScope(
      onWillPop: () async => false, // Block back button
      child: Scaffold(
        backgroundColor: Colors.black,
        body: GestureDetector(
          onTap: () => context.pop(),
          child: Stack(
            fit: StackFit.expand,
            children: [
              if (_message!['media_type'] == 'image')
                Image.network(_message!['media_url'], fit: BoxFit.cover),
              if (_message!['media_type'] == 'video' && _videoController != null && _videoController!.value.isInitialized)
                VideoPlayer(_videoController!),
              
              SafeArea(
                child: Align(
                  alignment: Alignment.topCenter,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: AnimatedBuilder(
                      animation: _animationController,
                      builder: (context, child) => LinearProgressIndicator(
                        value: _animationController.value,
                        backgroundColor: Colors.white30,
                        valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
                        minHeight: 4,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
