'use client';
import { useEffect, useState, useRef } from 'react';
import { supabase } from '@/lib/supabase/client';
import useAuth from '@/lib/hooks/useAuth';
import ChatBubble from '@/components/chat/ChatBubble';
import { ArrowLeft, Send } from 'lucide-react';
import Link from 'next/link';
import Avatar from '@/components/ui/Avatar';

export default function ChatThread({ params }: { params: { chatId: string } }) {
  const { user } = useAuth();
  const [messages, setMessages] = useState<any[]>([]);
  const [text, setText] = useState('');
  const [otherProfile, setOtherProfile] = useState<any>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Setup chat thread logic and subscriptions
  }, [params.chatId, user]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || !user) return;
    
    await supabase.from('messages').insert({
      chat_id: params.chatId,
      sender_id: user.id,
      content: text,
      message_type: 'text',
      status: 'sent'
    });
    setText('');
  };

  return (
    <div className="flex flex-col h-full relative bg-[#0D0D0D]">
      <header className="flex items-center gap-4 p-4 border-b border-white/10 bg-black/50 backdrop-blur-md sticky top-0 z-10">
        <Link href="/chat" className="text-white hover:text-[#FFFC00]">
          <ArrowLeft size={24} />
        </Link>
        <Avatar profile={otherProfile} size="md" />
        <h2 className="font-bold text-lg">{otherProfile?.display_name || 'Chat'}</h2>
      </header>

      <div className="flex-1 overflow-y-auto p-4 hide-scrollbar">
        {messages.map((msg) => (
          <ChatBubble key={msg.id} message={msg} isSent={msg.sender_id === user?.id} />
        ))}
        <div ref={scrollRef} />
      </div>

      <div className="p-4 bg-[#0D0D0D] border-t border-white/10">
        <form onSubmit={handleSend} className="flex items-center gap-2">
          <input 
            type="text" 
            value={text} 
            onChange={(e) => setText(e.target.value)} 
            placeholder="Send a chat..." 
            className="flex-1 bg-white/10 text-white rounded-full px-6 py-3 focus:outline-none focus:ring-1 focus:ring-[#FFFC00]" 
          />
          <button type="submit" className="p-3 bg-[#FFFC00] text-black rounded-full hover:brightness-110">
            <Send size={20} />
          </button>
        </form>
      </div>
    </div>
  );
}
