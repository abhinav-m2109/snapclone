import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

const snapYellow = Color(0xFFFFFC00);
const snapDark = Color(0xFF0D0D0D);

class MainShell extends StatelessWidget {
  final StatefulNavigationShell navigationShell;

  const MainShell({Key? key, required this.navigationShell}) : super(key: key);

  void _onTap(int index) {
    navigationShell.goBranch(
      index,
      initialLocation: index == navigationShell.currentIndex,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: snapDark,
      body: navigationShell,
      extendBody: true,
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.transparent, Colors.black87, Colors.black],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: BottomNavigationBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          type: BottomNavigationBarType.fixed,
          currentIndex: navigationShell.currentIndex,
          onTap: _onTap,
          selectedItemColor: snapYellow,
          unselectedItemColor: Colors.white54,
          showSelectedLabels: false,
          showUnselectedLabels: false,
          items: [
            const BottomNavigationBarItem(
              icon: Icon(Icons.map_outlined),
              label: 'Map',
            ),
            const BottomNavigationBarItem(
              icon: Icon(Icons.chat_bubble_outline),
              label: 'Chat',
            ),
            BottomNavigationBarItem(
              icon: Container(
                padding: const EdgeInsets.all(12),
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: snapYellow,
                ),
                child: const Icon(Icons.camera_alt, color: snapDark),
              ),
              label: 'Camera',
            ),
            const BottomNavigationBarItem(
              icon: Icon(Icons.auto_stories_outlined),
              label: 'Stories',
            ),
            const BottomNavigationBarItem(
              icon: Icon(Icons.explore_outlined),
              label: 'Discover',
            ),
          ],
        ),
      ),
    );
  }
}
