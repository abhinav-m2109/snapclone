import 'dart:io';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final supabaseServiceProvider = Provider((ref) => SupabaseService());

class SupabaseService {
  final SupabaseClient _client = Supabase.instance.client;

  User? get currentUser => _client.auth.currentUser;

  // Auth
  Future<AuthResponse> signUp(String email, String password) async {
    return await _client.auth.signUp(email: email, password: password);
  }

  Future<AuthResponse> signIn(String email, String password) async {
    return await _client.auth.signInWithPassword(email: email, password: password);
  }

  Future<void> signOut() async {
    await _client.auth.signOut();
  }

  // Profile
  Future<Map<String, dynamic>> getProfile(String userId) async {
    return await _client.from('profiles').select().eq('id', userId).single();
  }

  Future<void> updateProfile(Map<String, dynamic> data) async {
    await _client.from('profiles').upsert(data);
  }
  
  Future<bool> checkUsernameAvailable(String username) async {
    final res = await _client.from('profiles').select('id').eq('username', username).maybeSingle();
    return res == null;
  }

  // Friends
  Future<List<Map<String, dynamic>>> searchUsers(String query) async {
    return await _client.from('profiles').select().ilike('username', '%$query%').limit(20);
  }

  Future<void> sendFriendRequest(String userId) async {
    await _client.from('friendships').insert({
      'user_id': currentUser!.id,
      'friend_id': userId,
      'status': 'pending',
    });
  }

  Future<void> acceptFriendRequest(String friendshipId) async {
    await _client.from('friendships').update({'status': 'accepted'}).eq('id', friendshipId);
  }

  Future<List<dynamic>> getFriends() async {
    final res = await _client.rpc('get_friends', params: {'user_uuid': currentUser!.id});
    return res;
  }

  // Stories
  Future<List<Map<String, dynamic>>> getStories() async {
    return await _client.from('stories').select('*, profiles(*)').gt('expires_at', DateTime.now().toIso8601String()).order('created_at');
  }

  Future<void> uploadStory(File file, String type) async {
    final fileName = '${DateTime.now().millisecondsSinceEpoch}_${currentUser!.id}';
    await _client.storage.from('stories').upload(fileName, file);
    final url = _client.storage.from('stories').getPublicUrl(fileName);
    
    await _client.from('stories').insert({
      'user_id': currentUser!.id,
      'media_url': url,
      'media_type': type,
    });
  }

  Future<void> viewStory(String storyId) async {
    await _client.from('story_views').upsert({
      'story_id': storyId,
      'viewer_id': currentUser!.id,
    });
  }

  // Chat
  Future<List<Map<String, dynamic>>> getChatList() async {
    return await _client.from('chats').select('*, chat_participants!inner(*), messages(*)').order('updated_at', ascending: false);
  }

  Future<List<Map<String, dynamic>>> getMessages(String chatId) async {
    return await _client.from('messages').select().eq('chat_id', chatId).order('created_at');
  }
  
  Future<String> getOrCreateDirectChat(String otherUserId) async {
    final res = await _client.rpc('get_or_create_direct_chat', params: {'other_user_id': otherUserId});
    return res as String;
  }

  Future<void> sendTextMessage(String chatId, String text) async {
    await _client.from('messages').insert({
      'chat_id': chatId,
      'sender_id': currentUser!.id,
      'message_type': 'text',
      'content': text,
    });
  }

  Future<void> sendSnap(String chatId, File file, String type) async {
    final fileName = '${DateTime.now().millisecondsSinceEpoch}_${currentUser!.id}';
    await _client.storage.from('snaps').upload(fileName, file);
    final url = _client.storage.from('snaps').getPublicUrl(fileName);
    
    await _client.from('messages').insert({
      'chat_id': chatId,
      'sender_id': currentUser!.id,
      'message_type': type == 'video' ? 'snap_video' : 'snap_image',
      'content': url,
    });
  }

  Future<void> openSnap(String messageId) async {
    await _client.from('messages').update({'status': 'opened', 'opened_at': DateTime.now().toIso8601String()}).eq('id', messageId);
  }

  // Map
  Future<void> updateLocation(double lat, double lng) async {
    await _client.from('locations').upsert({
      'user_id': currentUser!.id,
      'latitude': lat,
      'longitude': lng,
      'updated_at': DateTime.now().toIso8601String(),
    });
  }
  
  Future<List<Map<String, dynamic>>> getFriendLocations() async {
    return await _client.from('locations').select('*, profiles!inner(*)');
  }

  // Discover
  Future<List<Map<String, dynamic>>> getDiscoverPosts(int page) async {
    final start = page * 20;
    return await _client.from('discover_posts').select('*, profiles(*)').range(start, start + 19).order('created_at', ascending: false);
  }
}
