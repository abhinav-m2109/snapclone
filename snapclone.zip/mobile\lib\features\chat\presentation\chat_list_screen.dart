import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:go_router/go_router.dart';

const snapDark = Color(0xFF0D0D0D);
const snapPurple = Color(0xFFB132B4);
const snapRed = Color(0xFFFF3B30);
const snapBlue = Color(0xFF007AFF);

class ChatListScreen extends StatefulWidget {
  const ChatListScreen({Key? key}) : super(key: key);

  @override
  State<ChatListScreen> createState() => _ChatListScreenState();
}

class _ChatListScreenState extends State<ChatListScreen> {
  List<Map<String, dynamic>> _chats = [];
  bool _isLoading = true;
  StreamSubscription? _sub;

  @override
  void initState() {
    super.initState();
    _loadChats();
    _setupSubscription();
  }

  Future<void> _loadChats() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser!.id;
      final res = await Supabase.instance.client.rpc('get_user_chats', params: {'user_id': userId});
      if (mounted) {
        setState(() {
          _chats = List<Map<String, dynamic>>.from(res as List);
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _setupSubscription() {
    _sub = Supabase.instance.client.channel('public:messages').onPostgresChanges(
      event: PostgresChangeEvent.insert,
      schema: 'public',
      table: 'messages',
      callback: (payload) {
        _loadChats();
      },
    ).subscribe();
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Widget _buildStatusIcon(Map<String, dynamic> chat) {
    final type = chat['last_message_type'];
    final status = chat['last_message_status'];
    final isMine = chat['last_message_sender_id'] == Supabase.instance.client.auth.currentUser!.id;

    if (type == null) return const SizedBox.shrink();

    Color color;
    if (type == 'snap' && chat['last_message_media_type'] == 'video') color = snapPurple;
    else if (type == 'snap') color = snapRed;
    else color = snapBlue;

    if (isMine) {
      if (status == 'opened') return Icon(Icons.change_history, color: Colors.grey, size: 16);
      return Icon(Icons.change_history, color: color, size: 16); // Filled technically
    } else {
      if (status == 'opened') return Icon(Icons.crop_square, color: Colors.grey, size: 16);
      return Icon(Icons.crop_square, color: color, size: 16); // Filled technically
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: snapDark,
      appBar: AppBar(
        backgroundColor: snapDark,
        title: const Text('Chat'),
        actions: [
          IconButton(icon: const Icon(Icons.person_add), onPressed: () => context.push('/friend-search')),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _chats.isEmpty
              ? const Center(child: Text('Add friends to start snapping!', style: TextStyle(color: Colors.white54)))
              : ListView.builder(
                  itemCount: _chats.length,
                  itemBuilder: (context, index) {
                    final chat = _chats[index];
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundImage: chat['avatar_url'] != null ? NetworkImage(chat['avatar_url']) : null,
                        child: chat['avatar_url'] == null ? const Icon(Icons.person) : null,
                      ),
                      title: Text(chat['display_name'] ?? chat['username'] ?? '', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                      subtitle: Row(
                        children: [
                          _buildStatusIcon(chat),
                          const SizedBox(width: 4),
                          Expanded(
                            child: Text(
                              chat['last_message_type'] == 'snap' ? 'New Snap' : (chat['last_message_content'] ?? 'Tap to chat'),
                              style: const TextStyle(color: Colors.white54),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                      onTap: () => context.push('/chat/${chat['chat_id']}'),
                    );
                  },
                ),
    );
  }
}
