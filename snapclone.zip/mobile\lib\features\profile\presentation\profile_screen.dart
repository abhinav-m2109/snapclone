import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:go_router/go_router.dart';

const snapDark = Color(0xFF0D0D0D);
const snapYellow = Color(0xFFFFFC00);

class ProfileScreen extends StatefulWidget {
  final String userId;

  const ProfileScreen({Key? key, required this.userId}) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  Map<String, dynamic>? _profile;
  Map<String, dynamic>? _stats;
  List<Map<String, dynamic>> _stories = [];
  bool _isLoading = true;
  final String _currentUserId = Supabase.instance.client.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    try {
      final res = await Supabase.instance.client.from('profiles').select().eq('id', widget.userId).single();
      
      // Load stats manually for now (can use RPC in real app)
      final friends = await Supabase.instance.client.from('friendships').select('id', const FetchOptions(count: CountOption.exact)).or('requester_id.eq.${widget.userId},addressee_id.eq.${widget.userId}').eq('status', 'accepted');
      final snaps = await Supabase.instance.client.from('messages').select('id', const FetchOptions(count: CountOption.exact)).eq('sender_id', widget.userId).eq('type', 'snap');
      
      final storiesRes = await Supabase.instance.client.from('stories').select().eq('user_id', widget.userId).order('created_at', ascending: false).limit(9);

      setState(() {
        _profile = res;
        _stats = {
          'friends': friends.count ?? 0,
          'snaps': snaps.count ?? 0,
          'score': (snaps.count ?? 0) * 10, // dummy score
        };
        _stories = List<Map<String, dynamic>>.from(storiesRes);
        _isLoading = false;
      });
    } catch (_) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _toggleGhostMode(bool val) async {
    try {
      await Supabase.instance.client.from('profiles').update({'ghost_mode': val}).eq('id', _currentUserId);
      setState(() => _profile!['ghost_mode'] = val);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) return const Scaffold(backgroundColor: snapDark, body: Center(child: CircularProgressIndicator()));
    if (_profile == null) return const Scaffold(backgroundColor: snapDark, body: Center(child: Text('Profile not found', style: TextStyle(color: Colors.white))));

    final isMine = widget.userId == _currentUserId;

    return Scaffold(
      backgroundColor: snapDark,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: isMine ? [IconButton(icon: const Icon(Icons.settings), onPressed: () {})] : null,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            CircleAvatar(
              radius: 52,
              backgroundImage: _profile!['avatar_url'] != null ? NetworkImage(_profile!['avatar_url']) : null,
              child: _profile!['avatar_url'] == null ? const Icon(Icons.person, size: 50) : null,
            ),
            const SizedBox(height: 16),
            Text(_profile!['display_name'] ?? '', style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
            Text('@${_profile!['username']}', style: const TextStyle(color: Colors.white54)),
            const SizedBox(height: 8),
            Text('Snap Score: ${_stats?['score'] ?? 0}', style: const TextStyle(color: snapYellow, fontWeight: FontWeight.bold)),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildStat('Friends', _stats?['friends'] ?? 0),
                _buildStat('Snaps', _stats?['snaps'] ?? 0),
                _buildStat('Stories', _stories.length),
              ],
            ),
            const SizedBox(height: 24),
            if (isMine) ...[
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: OutlinedButton(
                  onPressed: () {},
                  style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(40), side: const BorderSide(color: Colors.white)),
                  child: const Text('Edit Profile', style: TextStyle(color: Colors.white)),
                ),
              ),
              SwitchListTile(
                title: const Text('Ghost Mode', style: TextStyle(color: Colors.white)),
                subtitle: const Text('Hide location on map', style: TextStyle(color: Colors.white54)),
                value: _profile!['ghost_mode'] ?? false,
                onChanged: _toggleGhostMode,
                activeColor: snapYellow,
              ),
            ] else ...[
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: snapYellow, foregroundColor: Colors.black, minimumSize: const Size.fromHeight(40)),
                  onPressed: () {},
                  child: const Text('Message', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
              ),
            ],
            const SizedBox(height: 24),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Align(alignment: Alignment.centerLeft, child: Text('Recent Stories', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold))),
            ),
            const SizedBox(height: 8),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 8, mainAxisSpacing: 8, childAspectRatio: 0.7),
              itemCount: _stories.length,
              itemBuilder: (context, index) {
                final story = _stories[index];
                return ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: story['media_type'] == 'image'
                      ? Image.network(story['media_url'], fit: BoxFit.cover)
                      : Container(color: Colors.grey[900], child: const Icon(Icons.videocam, color: Colors.white)),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStat(String label, int value) {
    return Column(
      children: [
        Text(value.toString(), style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
        Text(label, style: const TextStyle(color: Colors.white54)),
      ],
    );
  }
}
