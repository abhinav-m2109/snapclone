import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        'snap-yellow': '#FFFC00',
        'snap-dark': '#0D0D0D',
        'snap-gray': '#1E1E1E',
        'snap-light-gray': '#2C2C2C',
        'snap-accent': '#B92CFF',
        'snap-red': '#FF0049',
        'snap-green': '#00FF00',
        'snap-blue': '#00A2FF',
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'gradient-conic': 'conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))',
        'snap-gradient': 'linear-gradient(135deg, #FFFC00 0%, #FF9900 100%)',
      },
      keyframes: {
        progress: {
          '0%': { width: '0%' },
          '100%': { width: '100%' },
        }
      },
      animation: {
        'progress': 'progress 5s linear forwards',
      }
    },
  },
  plugins: [],
};
export default config;
