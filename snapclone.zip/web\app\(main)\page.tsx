'use client';
import { useState } from 'react';
import WebcamCapture from '@/components/camera/WebcamCapture';
import { supabase } from '@/lib/supabase/client';
import useAuth from '@/lib/hooks/useAuth';
import SnapButton from '@/components/ui/SnapButton';

export default function CameraPage() {
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const { user } = useAuth();

  const handleCapture = (dataUrl: string) => {
    setCapturedImage(dataUrl);
  };

  const handleAddToStory = async () => {
    if (!capturedImage || !user) return;
    setUploading(true);
    try {
      const res = await fetch(capturedImage);
      const blob = await res.blob();
      const fileName = `${user.id}-${Date.now()}.jpg`;
      const { data: uploadData, error: uploadError } = await supabase.storage.from('stories').upload(fileName, blob, { contentType: 'image/jpeg' });
      if (uploadError) throw uploadError;
      
      const { data: publicUrlData } = supabase.storage.from('stories').getPublicUrl(fileName);
      
      const { error: insertError } = await supabase.from('stories').insert({
        profile_id: user.id,
        media_url: publicUrlData.publicUrl,
        media_type: 'image',
        audience: 'everyone',
      });
      if (insertError) throw insertError;
      alert('Story posted successfully!');
      setCapturedImage(null);
    } catch (err: any) {
      alert(err.message);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="w-full h-full bg-black relative flex items-center justify-center">
      {!capturedImage ? (
        <WebcamCapture onCapture={handleCapture} />
      ) : (
        <div className="absolute inset-0 flex flex-col items-center justify-center z-50 bg-black">
          <img src={capturedImage} alt="Preview" className="max-w-full max-h-[80vh] object-contain rounded-xl" />
          <div className="absolute bottom-10 flex gap-4">
            <SnapButton variant="ghost" onClick={() => setCapturedImage(null)}>Close</SnapButton>
            <SnapButton variant="primary" loading={uploading} onClick={handleAddToStory}>Add to Story</SnapButton>
          </div>
        </div>
      )}
    </div>
  );
}
