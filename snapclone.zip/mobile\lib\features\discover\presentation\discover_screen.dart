import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:cached_network_image/cached_network_image.dart';

const snapDark = Color(0xFF0D0D0D);

class DiscoverScreen extends StatefulWidget {
  const DiscoverScreen({Key? key}) : super(key: key);

  @override
  State<DiscoverScreen> createState() => _DiscoverScreenState();
}

class _DiscoverScreenState extends State<DiscoverScreen> {
  List<Map<String, dynamic>> _posts = [];
  bool _isLoading = true;
  bool _isLoadingMore = false;
  int _page = 0;
  final int _pageSize = 20;

  @override
  void initState() {
    super.initState();
    _loadPosts();
  }

  Future<void> _loadPosts({bool refresh = false}) async {
    if (refresh) {
      _page = 0;
      setState(() => _isLoading = true);
    } else {
      setState(() => _isLoadingMore = true);
    }

    try {
      final res = await Supabase.instance.client
          .from('discover_posts')
          .select('*, profiles(id, display_name, avatar_url)')
          .order('created_at', ascending: false)
          .range(_page * _pageSize, (_page + 1) * _pageSize - 1);
      
      setState(() {
        if (refresh) _posts = List<Map<String, dynamic>>.from(res);
        else _posts.addAll(List<Map<String, dynamic>>.from(res));
        _page++;
      });
    } catch (_) {
    } finally {
      setState(() {
        _isLoading = false;
        _isLoadingMore = false;
      });
    }
  }

  void _showMedia(Map<String, dynamic> post) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.black,
        insetPadding: EdgeInsets.zero,
        child: Stack(
          fit: StackFit.expand,
          children: [
            post['media_type'] == 'image'
              ? CachedNetworkImage(imageUrl: post['media_url'], fit: BoxFit.cover)
              : const Center(child: Icon(Icons.videocam, color: Colors.white, size: 50)),
            SafeArea(
              child: Align(
                alignment: Alignment.topRight,
                child: IconButton(icon: const Icon(Icons.close, color: Colors.white), onPressed: () => Navigator.pop(context)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: snapDark,
      appBar: AppBar(backgroundColor: snapDark, title: const Text('Discover')),
      body: RefreshIndicator(
        onRefresh: () => _loadPosts(refresh: true),
        child: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : NotificationListener<ScrollNotification>(
                onNotification: (ScrollNotification scrollInfo) {
                  if (!_isLoadingMore && scrollInfo.metrics.pixels == scrollInfo.metrics.maxScrollExtent) {
                    _loadPosts();
                    return true;
                  }
                  return false;
                },
                child: GridView.builder(
                  padding: const EdgeInsets.all(8),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    childAspectRatio: 0.75,
                    crossAxisSpacing: 8,
                    mainAxisSpacing: 8,
                  ),
                  itemCount: _posts.length + (_isLoadingMore ? 2 : 0),
                  itemBuilder: (context, index) {
                    if (index >= _posts.length) return const Center(child: CircularProgressIndicator());
                    
                    final post = _posts[index];
                    final profile = post['profiles'] ?? {};
                    return GestureDetector(
                      onTap: () => _showMedia(post),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            CachedNetworkImage(
                              imageUrl: post['media_url'], // If video, ideally use a thumbnail
                              fit: BoxFit.cover,
                              errorWidget: (context, url, error) => Container(color: Colors.grey[800], child: const Icon(Icons.error)),
                            ),
                            Container(
                              decoration: const BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [Colors.transparent, Colors.black87],
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                ),
                              ),
                            ),
                            Positioned(
                              bottom: 8,
                              left: 8,
                              right: 8,
                              child: Row(
                                children: [
                                  CircleAvatar(
                                    radius: 12,
                                    backgroundImage: profile['avatar_url'] != null ? NetworkImage(profile['avatar_url']) : null,
                                    child: profile['avatar_url'] == null ? const Icon(Icons.person, size: 12) : null,
                                  ),
                                  const SizedBox(width: 4),
                                  Expanded(child: Text(profile['display_name'] ?? '', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold), maxLines: 1, overflow: TextOverflow.ellipsis)),
                                  const Icon(Icons.remove_red_eye, color: Colors.white54, size: 12),
                                  const SizedBox(width: 2),
                                  Text('${post['view_count'] ?? 0}', style: const TextStyle(color: Colors.white54, fontSize: 12)),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
      ),
    );
  }
}
