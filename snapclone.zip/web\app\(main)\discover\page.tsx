'use client';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase/client';
import { DiscoverPost } from '@/lib/types';
import { motion } from 'framer-motion';
import Avatar from '@/components/ui/Avatar';

export default function DiscoverPage() {
  const [posts, setPosts] = useState<DiscoverPost[]>([]);

  useEffect(() => {
    const fetchPosts = async () => {
      const { data } = await supabase.from('discover_posts').select('*, profiles(*)').order('created_at', { ascending: false }).limit(20);
      if (data) setPosts(data);
    };
    fetchPosts();
  }, []);

  return (
    <div className="p-4 h-full overflow-y-auto">
      <h1 className="text-2xl font-bold mb-6 text-white">Discover</h1>
      
      <div className="columns-2 md:columns-3 gap-4 space-y-4">
        {posts.map((post: any, idx) => (
          <motion.div 
            key={post.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.05 }}
            className="relative rounded-xl overflow-hidden break-inside-avoid cursor-pointer group"
          >
            <img src={post.media_url} alt="" className="w-full h-auto object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
              <div className="absolute bottom-4 left-4 right-4 flex items-center gap-2">
                <Avatar profile={post.profiles} size="sm" />
                <div className="min-w-0">
                  <p className="font-semibold text-white text-sm truncate">{post.profiles?.display_name}</p>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
