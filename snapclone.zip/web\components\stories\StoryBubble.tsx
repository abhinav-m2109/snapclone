'use client';
import Avatar from '@/components/ui/Avatar';
import { Profile, Story } from '@/lib/types';
import { motion } from 'framer-motion';

export default function StoryBubble({ profile, stories, viewed, onClick }: { profile: Profile, stories: Story[], viewed: boolean, onClick: () => void }) {
  return (
    <motion.button 
      whileTap={{ scale: 0.9 }} 
      onClick={onClick}
      className="flex flex-col items-center gap-2 min-w-[72px]"
    >
      <Avatar profile={profile} size="lg" showRing ringViewed={viewed} />
      <span className="text-xs text-white w-full truncate text-center">{profile.display_name}</span>
    </motion.button>
  );
}
