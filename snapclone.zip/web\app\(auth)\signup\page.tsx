'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft, Check, X } from 'lucide-react';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabase/client';

export default function SignupPage() {
  const [email, setEmail] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [usernameStatus, setUsernameStatus] = useState<'idle' | 'checking' | 'available' | 'taken'>('idle');
  const router = useRouter();

  useEffect(() => {
    if (!username) {
      setUsernameStatus('idle');
      return;
    }
    const checkUsername = async () => {
      setUsernameStatus('checking');
      const { data } = await supabase.from('profiles').select('username').eq('username', username).maybeSingle();
      if (data) setUsernameStatus('taken');
      else setUsernameStatus('available');
    };
    const timeoutId = setTimeout(checkUsername, 600);
    return () => clearTimeout(timeoutId);
  }, [username]);

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    if (usernameStatus === 'taken') {
      setError('Username is already taken');
      return;
    }
    try {
      const { data, error: signUpError } = await supabase.auth.signUp({ email, password });
      if (signUpError) throw signUpError;
      if (data.user) {
        const { error: profileError } = await supabase.from('profiles').insert({
          id: data.user.id,
          username,
          display_name: displayName,
          email,
        });
        if (profileError) throw profileError;
        router.push('/');
      }
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#0D0D0D] via-[#1A1A2E] to-[#16213E] p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
        className="glass w-full max-w-md p-8 rounded-2xl flex flex-col items-center border border-white/10 relative"
      >
        <Link href="/login" className="absolute left-6 top-6 text-gray-400 hover:text-white">
          <ArrowLeft size={24} />
        </Link>
        <h1 className="text-3xl font-bold text-white mb-8">Sign Up</h1>
        
        <form onSubmit={handleSignup} className="w-full space-y-4">
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }}>
            <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full bg-[#1A1A1A] text-white px-4 py-3 rounded-lg border border-transparent focus:border-[#FFFC00] focus:outline-none transition-colors" required />
          </motion.div>
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>
            <input type="text" placeholder="Display Name" value={displayName} onChange={(e) => setDisplayName(e.target.value)} className="w-full bg-[#1A1A1A] text-white px-4 py-3 rounded-lg border border-transparent focus:border-[#FFFC00] focus:outline-none transition-colors" required />
          </motion.div>
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 }} className="relative">
            <input type="text" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} className="w-full bg-[#1A1A1A] text-white px-4 py-3 rounded-lg border border-transparent focus:border-[#FFFC00] focus:outline-none transition-colors" required />
            <div className="absolute right-3 top-3.5">
              {usernameStatus === 'available' && <Check size={20} className="text-green-500" />}
              {usernameStatus === 'taken' && <X size={20} className="text-red-500" />}
            </div>
          </motion.div>
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.4 }}>
            <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full bg-[#1A1A1A] text-white px-4 py-3 rounded-lg border border-transparent focus:border-[#FFFC00] focus:outline-none transition-colors" required />
          </motion.div>
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.5 }}>
            <input type="password" placeholder="Confirm Password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} className="w-full bg-[#1A1A1A] text-white px-4 py-3 rounded-lg border border-transparent focus:border-[#FFFC00] focus:outline-none transition-colors" required />
          </motion.div>
          
          {error && <p className="text-red-500 text-sm text-center">{error}</p>}

          <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }} type="submit" className="w-full bg-[#FFFC00] text-black font-bold py-3 rounded-lg mt-6 shadow-[0_0_15px_rgba(255,252,0,0.3)]">
            Create Account
          </motion.button>
        </form>
      </motion.div>
    </div>
  );
}
