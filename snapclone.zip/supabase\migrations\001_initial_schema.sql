-- supabase/migrations/001_initial_schema.sql

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Profiles Table (extends auth.users)
CREATE TABLE profiles (
    id UUID REFERENCES auth.users(id) PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    display_name TEXT NOT NULL,
    avatar_url TEXT,
    snap_score INTEGER DEFAULT 0,
    ghost_mode BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Friendships Table
CREATE TYPE friendship_status AS ENUM ('pending', 'accepted', 'blocked');

CREATE TABLE friendships (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES profiles(id) NOT NULL,
    friend_id UUID REFERENCES profiles(id) NOT NULL,
    status friendship_status DEFAULT 'pending',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, friend_id)
);

-- Stories Table
CREATE TABLE stories (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES profiles(id) NOT NULL,
    media_url TEXT NOT NULL,
    media_type TEXT NOT NULL, -- 'image' or 'video'
    duration INTEGER DEFAULT 5, -- seconds for images
    caption TEXT,
    expires_at TIMESTAMPTZ DEFAULT NOW() + INTERVAL '24 hours',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Story Views Table
CREATE TABLE story_views (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    story_id UUID REFERENCES stories(id) ON DELETE CASCADE,
    viewer_id UUID REFERENCES profiles(id) NOT NULL,
    viewed_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(story_id, viewer_id)
);

-- Chats Table
CREATE TABLE chats (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    is_group BOOLEAN DEFAULT FALSE,
    name TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Chat Participants Table
CREATE TABLE chat_participants (
    chat_id UUID REFERENCES chats(id) ON DELETE CASCADE,
    user_id UUID REFERENCES profiles(id) NOT NULL,
    joined_at TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (chat_id, user_id)
);

-- Messages Table
CREATE TYPE message_type AS ENUM ('text', 'snap_image', 'snap_video');
CREATE TYPE snap_status AS ENUM ('sent', 'delivered', 'opened');

CREATE TABLE messages (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    chat_id UUID REFERENCES chats(id) ON DELETE CASCADE,
    sender_id UUID REFERENCES profiles(id) NOT NULL,
    message_type message_type NOT NULL,
    content TEXT, -- text content or media url
    status snap_status DEFAULT 'sent',
    duration INTEGER, -- for snaps
    created_at TIMESTAMPTZ DEFAULT NOW(),
    opened_at TIMESTAMPTZ
);

-- Locations Table
CREATE TABLE locations (
    user_id UUID REFERENCES profiles(id) PRIMARY KEY,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Discover Posts Table
CREATE TABLE discover_posts (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES profiles(id) NOT NULL,
    media_url TEXT NOT NULL,
    media_type TEXT NOT NULL,
    caption TEXT,
    likes_count INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Row Level Security (RLS)

-- Profiles
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public profiles are viewable by everyone" ON profiles FOR SELECT USING (true);
CREATE POLICY "Users can update their own profile" ON profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Users can insert their own profile" ON profiles FOR INSERT WITH CHECK (auth.uid() = id);

-- Friendships
ALTER TABLE friendships ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view their friendships" ON friendships FOR SELECT USING (auth.uid() = user_id OR auth.uid() = friend_id);
CREATE POLICY "Users can manage their friendships" ON friendships FOR ALL USING (auth.uid() = user_id OR auth.uid() = friend_id);

-- Stories
ALTER TABLE stories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view active stories of friends" ON stories FOR SELECT USING (
    expires_at > NOW() AND (
        user_id = auth.uid() OR
        EXISTS (
            SELECT 1 FROM friendships
            WHERE status = 'accepted' AND (
                (user_id = auth.uid() AND friend_id = stories.user_id) OR
                (friend_id = auth.uid() AND user_id = stories.user_id)
            )
        )
    )
);
CREATE POLICY "Users can create their own stories" ON stories FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Story Views
ALTER TABLE story_views ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view views of their stories" ON story_views FOR SELECT USING (
    EXISTS (SELECT 1 FROM stories WHERE id = story_id AND user_id = auth.uid())
);
CREATE POLICY "Users can record their own views" ON story_views FOR INSERT WITH CHECK (auth.uid() = viewer_id);

-- Chats
ALTER TABLE chats ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view chats they are in" ON chats FOR SELECT USING (
    EXISTS (SELECT 1 FROM chat_participants WHERE chat_id = id AND user_id = auth.uid())
);
CREATE POLICY "Users can create chats" ON chats FOR INSERT WITH CHECK (true);

-- Chat Participants
ALTER TABLE chat_participants ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view participants of their chats" ON chat_participants FOR SELECT USING (
    EXISTS (SELECT 1 FROM chat_participants cp WHERE cp.chat_id = chat_id AND cp.user_id = auth.uid())
);
CREATE POLICY "Users can manage their participation" ON chat_participants FOR ALL USING (user_id = auth.uid());

-- Messages
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view messages in their chats" ON messages FOR SELECT USING (
    EXISTS (SELECT 1 FROM chat_participants WHERE chat_id = messages.chat_id AND user_id = auth.uid())
);
CREATE POLICY "Users can send messages to their chats" ON messages FOR INSERT WITH CHECK (
    EXISTS (SELECT 1 FROM chat_participants WHERE chat_id = messages.chat_id AND user_id = auth.uid()) AND
    auth.uid() = sender_id
);
CREATE POLICY "Users can update status of received snaps" ON messages FOR UPDATE USING (
    EXISTS (SELECT 1 FROM chat_participants WHERE chat_id = messages.chat_id AND user_id = auth.uid()) AND
    auth.uid() != sender_id
);

-- Locations
ALTER TABLE locations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view locations of friends not in ghost mode" ON locations FOR SELECT USING (
    user_id = auth.uid() OR (
        NOT EXISTS (SELECT 1 FROM profiles WHERE id = locations.user_id AND ghost_mode = true) AND
        EXISTS (
            SELECT 1 FROM friendships
            WHERE status = 'accepted' AND (
                (user_id = auth.uid() AND friend_id = locations.user_id) OR
                (friend_id = auth.uid() AND user_id = locations.user_id)
            )
        )
    )
);
CREATE POLICY "Users can update their own location" ON locations FOR ALL USING (auth.uid() = user_id);

-- Discover Posts
ALTER TABLE discover_posts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Discover posts are viewable by everyone" ON discover_posts FOR SELECT USING (true);
CREATE POLICY "Users can manage their discover posts" ON discover_posts FOR ALL USING (auth.uid() = user_id);

-- Helper Functions
CREATE OR REPLACE FUNCTION get_or_create_direct_chat(other_user_id UUID)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    existing_chat_id UUID;
    new_chat_id UUID;
BEGIN
    SELECT c.id INTO existing_chat_id
    FROM chats c
    JOIN chat_participants cp1 ON c.id = cp1.chat_id
    JOIN chat_participants cp2 ON c.id = cp2.chat_id
    WHERE c.is_group = FALSE
      AND cp1.user_id = auth.uid()
      AND cp2.user_id = other_user_id;

    IF existing_chat_id IS NOT NULL THEN
        RETURN existing_chat_id;
    END IF;

    INSERT INTO chats (is_group) VALUES (FALSE) RETURNING id INTO new_chat_id;
    INSERT INTO chat_participants (chat_id, user_id) VALUES (new_chat_id, auth.uid()), (new_chat_id, other_user_id);

    RETURN new_chat_id;
END;
$$;

CREATE OR REPLACE FUNCTION cleanup_expired_stories()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    DELETE FROM stories WHERE expires_at < NOW();
END;
$$;

-- Indexes
CREATE INDEX idx_friendships_user_id ON friendships(user_id);
CREATE INDEX idx_friendships_friend_id ON friendships(friend_id);
CREATE INDEX idx_stories_user_id ON stories(user_id);
CREATE INDEX idx_stories_expires_at ON stories(expires_at);
CREATE INDEX idx_messages_chat_id ON messages(chat_id);
CREATE INDEX idx_messages_created_at ON messages(created_at);
CREATE INDEX idx_chat_participants_user_id ON chat_participants(user_id);
