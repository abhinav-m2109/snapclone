'use client';
import { Profile } from '@/lib/types';
import { cn, getInitials } from '@/lib/utils';
import { motion } from 'framer-motion';

export default function Avatar({ 
  profile, 
  size = 'md', 
  showRing, 
  ringViewed, 
  showOnline, 
  onClick 
}: { 
  profile: Profile | null, 
  size?: 'sm' | 'md' | 'lg' | 'xl', 
  showRing?: boolean, 
  ringViewed?: boolean, 
  showOnline?: boolean, 
  onClick?: () => void 
}) {
  const sizeMap = {
    sm: "w-8 h-8 text-xs",
    md: "w-10 h-10 text-sm",
    lg: "w-14 h-14 text-base",
    xl: "w-20 h-20 text-lg"
  };

  const Component = onClick ? motion.button : 'div';
  const onClickProps = onClick ? { onClick, whileHover: { scale: 1.05 }, whileTap: { scale: 0.95 } } : {};

  return (
    <div className="relative inline-block">
      <Component 
        {...onClickProps}
        className={cn(
          "rounded-full flex items-center justify-center overflow-hidden bg-gray-800 text-white font-semibold relative",
          sizeMap[size],
          showRing && !ringViewed && "p-[2px] bg-gradient-to-tr from-[#FFFC00] to-[#FF3B30]",
          showRing && ringViewed && "p-[2px] bg-gray-600"
        )}
      >
        <div className="w-full h-full rounded-full overflow-hidden bg-gray-800 flex items-center justify-center border-2 border-black">
          {profile?.avatar_url ? (
            <img src={profile.avatar_url} alt={profile.display_name} className="w-full h-full object-cover" />
          ) : (
            <span>{getInitials(profile?.display_name || '')}</span>
          )}
        </div>
      </Component>
      {showOnline && (
        <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-black" />
      )}
    </div>
  );
}
