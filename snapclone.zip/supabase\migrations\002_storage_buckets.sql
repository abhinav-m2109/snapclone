-- supabase/migrations/002_storage_buckets.sql

-- Create storage buckets
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES
  ('avatars', 'avatars', true, 5242880, ARRAY['image/jpeg', 'image/png', 'image/gif', 'image/webp']), -- 5MB
  ('stories', 'stories', false, 52428800, ARRAY['image/jpeg', 'image/png', 'video/mp4', 'video/quicktime']), -- 50MB
  ('snaps', 'snaps', false, 26214400, ARRAY['image/jpeg', 'image/png', 'video/mp4', 'video/quicktime']), -- 25MB
  ('discover', 'discover', true, 52428800, ARRAY['image/jpeg', 'image/png', 'video/mp4', 'video/quicktime']); -- 50MB

-- RLS Policies for Storage

-- Avatars (Public Read, Authenticated Insert/Update for own avatar)
CREATE POLICY "Avatars are publicly accessible" ON storage.objects FOR SELECT USING (bucket_id = 'avatars');
CREATE POLICY "Users can upload their own avatars" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'avatars' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Users can update their own avatars" ON storage.objects FOR UPDATE USING (bucket_id = 'avatars' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Stories (Authenticated Read for friends, Authenticated Insert for own)
CREATE POLICY "Users can view stories" ON storage.objects FOR SELECT USING (bucket_id = 'stories' AND auth.role() = 'authenticated');
CREATE POLICY "Users can upload their own stories" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'stories' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Snaps (Authenticated Read for chat participants, Authenticated Insert for sender)
CREATE POLICY "Users can view snaps" ON storage.objects FOR SELECT USING (bucket_id = 'snaps' AND auth.role() = 'authenticated');
CREATE POLICY "Users can upload their own snaps" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'snaps' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Discover (Public Read, Authenticated Insert/Update for own posts)
CREATE POLICY "Discover posts are publicly accessible" ON storage.objects FOR SELECT USING (bucket_id = 'discover');
CREATE POLICY "Users can upload discover posts" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'discover' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Users can update their discover posts" ON storage.objects FOR UPDATE USING (bucket_id = 'discover' AND auth.uid()::text = (storage.foldername(name))[1]);
