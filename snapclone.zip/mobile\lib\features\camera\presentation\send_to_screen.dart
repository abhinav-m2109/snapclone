import 'dart:io';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:go_router/go_router.dart';
import 'package:uuid/uuid.dart';

const snapYellow = Color(0xFFFFFC00);
const snapDark = Color(0xFF0D0D0D);

class SendToScreen extends StatefulWidget {
  final Map<String, dynamic> extra;

  const SendToScreen({Key? key, required this.extra}) : super(key: key);

  @override
  State<SendToScreen> createState() => _SendToScreenState();
}

class _SendToScreenState extends State<SendToScreen> {
  List<Map<String, dynamic>> _friends = [];
  final Set<String> _selectedIds = {};
  bool _isLoading = true;
  bool _isSending = false;

  @override
  void initState() {
    super.initState();
    _loadFriends();
  }

  Future<void> _loadFriends() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser!.id;
      final res = await Supabase.instance.client
          .from('friendships')
          .select('id, profiles!friendships_addressee_id_fkey(id, username, display_name, avatar_url)')
          .eq('requester_id', userId)
          .eq('status', 'accepted');
      
      final res2 = await Supabase.instance.client
          .from('friendships')
          .select('id, profiles!friendships_requester_id_fkey(id, username, display_name, avatar_url)')
          .eq('addressee_id', userId)
          .eq('status', 'accepted');

      final List<Map<String, dynamic>> combined = [];
      for (var row in res) {
        combined.add(row['profiles'] as Map<String, dynamic>);
      }
      for (var row in res2) {
        combined.add(row['profiles'] as Map<String, dynamic>);
      }

      setState(() {
        _friends = combined;
        _isLoading = false;
      });
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _send() async {
    setState(() => _isSending = true);
    try {
      final userId = Supabase.instance.client.auth.currentUser!.id;
      final imagePath = widget.extra['imagePath'] as String?;
      final videoPath = widget.extra['videoPath'] as String?;
      final caption = widget.extra['caption'] as String?;
      final addToStory = widget.extra['addToStory'] as bool? ?? false;
      
      final path = imagePath ?? videoPath;
      if (path == null) return;
      final ext = path.split('.').last;
      final isVideo = videoPath != null;

      if (addToStory) {
        final uuid = const Uuid().v4();
        final storagePath = 'stories/$userId/$uuid.$ext';
        await Supabase.instance.client.storage.from('stories').upload(storagePath, File(path));
        final url = Supabase.instance.client.storage.from('stories').getPublicUrl(storagePath);
        await Supabase.instance.client.from('stories').insert({
          'user_id': userId,
          'media_url': url,
          'media_type': isVideo ? 'video' : 'image',
          'caption': caption,
          'duration': isVideo ? 10 : 5,
        });
      }

      for (final friendId in _selectedIds) {
        final rpcRes = await Supabase.instance.client.rpc('get_or_create_direct_chat', params: {'other_user_id': friendId});
        final chatId = rpcRes as String;
        
        final uuid = const Uuid().v4();
        final storagePath = 'snaps/$userId/$chatId/$uuid.$ext';
        await Supabase.instance.client.storage.from('snaps').upload(storagePath, File(path));
        final url = Supabase.instance.client.storage.from('snaps').getPublicUrl(storagePath);
        
        await Supabase.instance.client.from('messages').insert({
          'chat_id': chatId,
          'sender_id': userId,
          'type': 'snap',
          'media_url': url,
          'duration': isVideo ? 10 : 5,
        });
      }

      if (mounted) context.go('/camera');
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final addToStoryOnly = widget.extra['addToStory'] == true && _selectedIds.isEmpty;

    return Scaffold(
      backgroundColor: snapDark,
      appBar: AppBar(
        backgroundColor: snapDark,
        title: const Text('Send To'),
        actions: [
          if (_selectedIds.isNotEmpty || addToStoryOnly)
            TextButton(
              onPressed: _isSending ? null : _send,
              child: _isSending 
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: snapYellow, strokeWidth: 2))
                : const Text('Send', style: TextStyle(color: snapYellow, fontWeight: FontWeight.bold)),
            )
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: _friends.length,
              itemBuilder: (context, index) {
                final friend = _friends[index];
                final id = friend['id'] as String;
                final isSelected = _selectedIds.contains(id);
                return ListTile(
                  leading: CircleAvatar(
                    backgroundImage: friend['avatar_url'] != null ? NetworkImage(friend['avatar_url']) : null,
                    child: friend['avatar_url'] == null ? const Icon(Icons.person) : null,
                  ),
                  title: Text(friend['display_name'] ?? '', style: const TextStyle(color: Colors.white)),
                  subtitle: Text(friend['username'] ?? '', style: const TextStyle(color: Colors.white54)),
                  trailing: Icon(
                    isSelected ? Icons.check_circle : Icons.circle_outlined,
                    color: isSelected ? snapYellow : Colors.white54,
                  ),
                  onTap: () {
                    setState(() {
                      if (isSelected) _selectedIds.remove(id);
                      else _selectedIds.add(id);
                    });
                  },
                );
              },
            ),
    );
  }
}
