'use client';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase/client';

export function useRealtime(table: string, filter: string, callback: (payload: any) => void) {
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    const channel = supabase.channel(`public:${table}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table, filter },
        (payload) => {
          callback(payload);
        }
      )
      .subscribe((status) => {
        setIsConnected(status === 'SUBSCRIBED');
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, [table, filter, callback]);

  return { isConnected };
}
